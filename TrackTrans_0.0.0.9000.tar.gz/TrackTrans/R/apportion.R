#' Generate bootstrap estimates of usage in bounded region
#'
#' @param dr number of draws from the posterior, for boostrapping
#' @param pars A data frame of parameter values, ordered.
#' @param covariates A list of covariate rasters
#' @param dis A list of distance rasters
#' @param pa Proportion of adults in population
#' @param pop Vector of population sizes
#' @param boundary A shape file for area boundary
#' @param weighted Logical. Whether the estimates should be presented in weighted form as absolute usage (TRUE) or as a proportion of total usage of that colony/age component (FALSE).
#' @return A pp-by-2 matrix of candidate positions
#' @export


apportion<-function(dr, pars, covariates, dis, pa,pop, boundary, weighted=TRUE)
{
  nC<-length(pop)
  nCov<-length(covariates)
  ciP<-5 # Confidence interval percentile

  med<-lo<-hi<-matrix(0,nC,2) # Summary results

  for(i in 1:nC) # Colonies
  {
    for(j in 1:2) # juveniles/Adults
    {
      dat<-rep(0,dr)
      for(k in 1:dr) # MCMC draws
      {
        if(nCov>0)
        {
          env<-dis[[1]]*0
          for(c in 1:nCov) # Env covariates
          {
            env<-env+covariates[[c]]*pars[k,1+(j-1)*(nCov+1)+c]
          }
        }
        us<-exp(env-pars[k,1+j*(nCov+1)]*dis[[i]])
        us<-us/sum(na.omit(us@data@values))
        dat[k]<-sum(raster::extract(us, boundary, fun = sum, na.rm = TRUE)*100)


      }
      datW<-(pop[i]/sum(pop)*(pa*(2-j)+(1-pa)*(j-1))*weighted+(1-weighted))*dat
      med[i,j]<-mean(datW)
      lo[i,j]<-sort(datW)[ceiling(ciP/200*dr)]
      hi[i,j]<-sort(datW)[floor((1-ciP/200)*dr)]
    }

  }

  return(list(med,lo,hi))
}
