#' Generate boostrap plot of all usage components (map form)
#'
#' @param dr number of draws from the posterior, for boostrapping
#' @param pars A data frame of parameter values, ordered.
#' @param covariates A list of covariate rasters
#' @param dis A list of distance rasters
#' @param pa Proportion of adults in population
#' @param pop Vector of population sizes
#' @param boundary A shape file for area boundary
#' @param weighted Logical. Whether the estimates should be presented in weighted form as absolute usage (TRUE) or as a proportion of total usage of that colony/age component (FALSE).
#' @return A pp-by-2 matrix of candidate positions
#' @export


apportionPlot<-function(dr, pars, covariates, dis, coast, pa,pop, dimPlot=c(4,2), mapTrue=NULL, zlim=NULL)
{

  nC<-length(pop)
  nCov<-length(covariates)
  dum<-covariates[[1]]*0
  dum@data@names<-"Usage"
  us<-usJ<-usA<-dum
  usCJ<-usCA<-replicate(nC, dum,simplify = F)

  for(k in 1:dr)
  {
    for(i in 1:nC)
    {
      for(j in 1:2) #Adults/juveniles
      {
        #Accessibility into the linear predictor first
        l<- - pars[k,1+(1+nCov)*j]*dis[[i]]
        if(nCov>0)
        {
          for(c in 1:nCov)
          {
            l<-l+pars[k,1+(j-1)*(nCov+1)+c]*covariates[[c]]
          }
        }
        if(j==2)
        {
          usCJ[[i]]<-usCJ[[i]]+1/dr*exp(l)/sum(na.omit(exp(l)@data@values))
        } else {
          usCA[[i]]<-usCA[[i]]+1/dr*exp(l)/sum(na.omit(exp(l)@data@values))
        }
      }
      usA<-usA+pop[i]*usCA[[i]]
      usJ<-usJ+pop[i]*usCJ[[i]]
    }
    usA<-usA/sum(na.omit(usA@data@values))
    usJ<-usJ/sum(na.omit(usJ@data@values))
  }
  us<-(pa*usA+(1-pa)*usJ)

  if(is.null(zlim))
  {
    ord<-sort(na.omit(us@data@values))
    maxlim<-ord[which.min(abs(cumsum(ord)-0.9))]
  } else {
    maxlim<-zlim
  }


  par(mfrow=dimPlot)
  for(i in 1:nC)
    {
    image(usCJ[[i]], main=paste("Juveniles, Colony",i), zlim=c(0,maxlim))
    image(usCA[[i]], main=paste("Adults, Colony",i), zlim=c(0,maxlim))
  }
  image(usA, main="Adults", zlim=c(0,maxlim))
  image(usJ, main="Juveniles", zlim=c(0,maxlim))
  image(us, main="Aggregate", zlim=c(0,maxlim))
  if(is.null(mapTrue)==0)
  {
    image(mapTrue, main="True Aggregate", zlim=c(0,maxlim))
  }
  par(mfrow=c(1,1))
}
