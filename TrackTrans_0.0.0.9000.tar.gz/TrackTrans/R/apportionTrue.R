#' Calculate apportionment of real usage from simulation results
#'
#' @param usageColJu A list of usage maps for juveniles of each colony
#' @param usageColAd A list of usage maps for adults of each colony
#' @param pa Proportion of adults in population
#' @param pop Vector of population sizes
#' @param boundary A shape file for area boundary
#' @param weighted Logical. Whether the estimates should be presented in weighted form as absolute usage (TRUE) or as a proportion of total usage of that colony/age component (FALSE).
#' @return A pp-by-2 matrix of candidate positions
#' @export


apportionTrue<-function(usageColJu, usageColAd, pa,pop, boundary, weighted=TRUE)
{
  nC<-length(pop)
  tru<-matrix(0,nC,2) # Summary results

  for(i in 1:nC) # Colonies
  {

    tru[i,2]<-sum(raster::extract(usageColJu[[i]]/sum(na.omit(usageColJu[[i]]@data@values)), boundary, fun = sum, na.rm = TRUE)*100)
    tru[i,1]<-sum(raster::extract(usageColAd[[i]]/sum(na.omit(usageColAd[[i]]@data@values)), boundary, fun = sum, na.rm = TRUE)*100)

    weights<-c(pa,(1-pa))%*%t(pop/sum(pop))
    weights<-weights/sum(weights)
    if(weighted==TRUE) tru<-tru*weights
  }

  return(tru)
}
