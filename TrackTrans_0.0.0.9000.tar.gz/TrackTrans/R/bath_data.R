#' Data containing bathymetry values for marine study area
#'
#' Contains depth in meters
#'
#' @format A raster
#'
#' @source Aggregated in-house

#' data(bath) # Lazy loading. Data becomes visible as soon as package is loaded
#' image(bath)
"bath"
