#' Data containing coastline shape marine study area
#'
#' Aggregated coastline
#'
#' @format A shape file
#'
#' @source Aggregated in-house

#' data(coast) # Lazy loading. Data becomes visible as soon as package is loaded
#' plot(coast)
"coast"
