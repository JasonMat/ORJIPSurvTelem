#' Generating a list of distance rasters from given central places
#'
#' @param roCol x coordinates for central places
#' @param coCol y coordinates for central places
#' @param obstacles A raster of impassable cells
#' @param obsV Cell value in obstacles raster indicating impassable cells
#' @return A list of distance rasters
#' @export



colDis<-function(roCol, coCol, obstacles, obsV)
{
  # List of all distance matrices (one for each colony)
  dis<-list()
  nC<-length(roCol)
  for( i in 1:nC)
  {
    obs<-obstacles*0+1
    if(is.na(obsV))
    {
      obs@data@values[is.na(obs@data@values)]<-0
    } else
    {
      obs@data@values[obs@data@values==obsV]<-0
    }
    obs[roCol[i],coCol[i]]<-2
    d1<-raster::gridDistance(obs,origin=2, omit=0)
    dis<-append(dis,d1)
    if(i==1)
    {dCol<-d1
    } else {
      dCol<-dCol+d1
    }
  }
return(dis)
}
