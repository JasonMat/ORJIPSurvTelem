#' Augmenting telemetry data set with covariate layer data (unprocessed covariate values and smoothed gradients)
#'
#' @param covs A list of covariate stacks (raw values and smoothed gradients)
#' @param condReg Options for conditional regression: 1) control points, 2) boundary, 3) Diffusivity
#'
#' @return An data frame of transect positions with detection counts and covariate values
#' @export



covariatesTrack<-function(tagData, colTagged, ageTagged, covs, di, condReg)
{

  noTg<-length(tagData)

  tagDataFrame<-data.frame( Use=integer(), RowS=integer(), ColS=integer(), RowE=integer(), ColE=integer(),
                            TimeS=integer(),TimeE=integer(),xS=integer(),yS=integer(), xE=integer(),
                            yE=integer(), animalID=integer(), pointID=integer())

  # Augmentation with the covariate columns
  for(i in 1:length(covs))
  {
    tagDataFrame<-data.frame(tagDataFrame,numeric(),numeric(),numeric())
    names(tagDataFrame)[ncol(tagDataFrame)-2]<-names(covs[[i]])[1]
    names(tagDataFrame)[ncol(tagDataFrame)-1]<-paste(names(covs[[i]])[1],".x",sep="")
    names(tagDataFrame)[ncol(tagDataFrame)]<-paste(names(covs[[i]])[1],".y",sep="")
  }
  tagDataFrame<-data.frame(tagDataFrame, "di"=numeric(),"di.x"=numeric(),"di.y"=numeric())
  naming<-names(tagDataFrame)

  ptID<-1
  for(i in 1:noTg)
  {
    print(i)
    # Colony where the current animal was tagged
    colony<-colTagged[i]

    for(j in 1:(nrow(tagData[[i]])-1))
    {

      # Generate use data column
      Use<-c(1,rep(0,condReg[[1]])) # Complements use point with availability points as, required by conditional regression option

      # Generate spatial coordinate data
      # Take current location row of data
      curr<-tagData[[i]][j,]
      Scoords<-c(x=curr[1], y=curr[2])
      # Take next location row of data
      nxt<-tagData[[i]][j+1,]
      Ecoords<-c(x=nxt[1], y=nxt[2])

      if (condReg[[1]]>0)
      {

        # Generate control points for current location
        coords<-fSteps(condReg[[1]], sigma=condReg[[3]]*sqrt(nxt[3]-curr[3]),
                       x=curr[1], y=curr[2],
                       covs=append(covs,di[[colony]]), condReg[[2]])
        # Combine control point coordinates with selected location (i.e. the next one)
        Ecoords<-rbind(Ecoords, coords)

        RowS<-rowFromY(covs[[1]][[1]], rep(Scoords[2], condReg[[1]]+1))
        ColS<-colFromX(covs[[1]][[1]], rep(Scoords[1], condReg[[1]]+1))
        RowE<-rowFromY(covs[[1]][[1]], Ecoords[,2])
        ColE<-colFromX(covs[[1]][[1]], Ecoords[,1])
        # Generate x and y coordinates in meters
        xS<-rep(Scoords[1], condReg[[1]]+1)
        yS<-rep(Scoords[2], condReg[[1]]+1)
        xE<-Ecoords[,1]
        yE<-Ecoords[,2]
      } else {
        RowS<-rowFromY(covs[[1]][[1]], Scoords[2])
        ColS<-colFromX(covs[[1]][[1]], Scoords[1])
        RowE<-rowFromY(covs[[1]][[1]], Ecoords[2])
        ColE<-colFromX(covs[[1]][[1]], Ecoords[1])
        # Generate x and y coordinates in meters
        xS<-Scoords[1]
        yS<-Scoords[2]
        xE<-Ecoords[1]
        yE<-Ecoords[2]
      }
      rcS<-cbind(RowS, ColS)
      rcE<-cbind(RowE, ColE)

      # Generate time column
      TimeS<-rep(curr[3], condReg[[1]]+1)
      TimeE<-rep(nxt[3], condReg[[1]]+1)


      # Covariates
      if(length(covs)>0)
      {
        covChunk<-cbind(covs[[1]][[1]][rcE], covs[[1]][[2]][rcS], covs[[1]][[3]][rcS])
      }
      if (length(covs)>1)
      {
        for(cc in 2:length(covs))
        {
          covChunk<-cbind(covChunk, covs[[cc]][[1]][rcE], covs[[cc]][[2]][rcS], covs[[cc]][[3]][rcS])
        }
      }

      Dis<-cbind(di[[colony]][[1]][rcE],di[[colony]][[2]][rcS],di[[colony]][[3]][rcS])
      # Animal ID
      animalID<-rep(i,condReg[[1]]+1)
      # Point ID
      pointID<-rep(ptID, condReg[[1]]+1)

      chunk<-cbind(Use, RowS, ColS, RowE, ColE, TimeS, TimeE, xS,yS,xE,yE, animalID, pointID, covChunk, Dis)
      tagDataFrame<-rbind(tagDataFrame, chunk)

      ptID<-ptID+1
    }
  }
  names(tagDataFrame)<-naming

  return(tagDataFrame)


}
