#' Augmenting survey data with covariate values
#'
#' @param surveyDat Locations of transect stations and corresponding counts
#' @param covs A list of covariate rasters
#' @param di A list of rasters containing distances from central places
#'
#' @return An data frame of transect positions with detection counts and covariate values
#' @export



covariateTrans<-function(surveyDat,covs,di)
{

  # Augmentation with the covariate data
  for(i in 1:length(covs))
  {
    surveyDat<-cbind(surveyDat, covs[[i]][[1]][cbind(surveyDat$Row, surveyDat$Col)])
    names(surveyDat)[ncol(surveyDat)]<-names(covs[[i]])[1]
  }
  for(i in 1:length(di))
  {
    surveyDat<-cbind(surveyDat, di[[i]][[1]][cbind(surveyDat$Row, surveyDat$Col)])
    names(surveyDat)[ncol(surveyDat)]<-paste("D",i, sep="")
  }

  return(surveyDat)
}
