#' Data containing bathymetry values for marine study area
#'
#' Contains depth in meters
#'
#' @format A crs definition
#'
#' @source Based on rasters used as examples

#' data(crsDef) # Lazy loading. Data becomes visible as soon as package is loaded
"crsDef"
