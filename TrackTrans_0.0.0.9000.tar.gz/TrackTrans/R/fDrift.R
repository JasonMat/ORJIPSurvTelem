#' Generates the x and y components of drift for a given covariate under Langevin diffusion
#'
#' @param rast The covariate raster to be processed
#' @param bw The smoothing window used to account for discrete time movement
#' @import ctmcmove
#' @return A stack of rasters containing original and two gradient component rasters
#' @export


fDrift<-function(rast,bw=NA)
{
  grad<-rast.grad(rast)

  if(is.na(bw)==FALSE)
  {
    bxw<-raster::focalWeight(x=grad$rast.grad.x, d=bw, type=c('Gauss'))
    bx<-raster::focal(x=grad$rast.grad.x,bxw, pad=TRUE, padValue=0)
    byw<-raster::focalWeight(x=grad$rast.grad.y, d=bw, type=c('Gauss'))
    by<-raster::focal(x=grad$rast.grad.y,byw, pad=TRUE, padValue=0)
  } else
  {
    bx<-grad$rast.grad.x
    by<-grad$rast.grad.y
  }

  bx@data@names<-"bx"
  by@data@names<-"by"
  return(stack(rast,bx,by))
}
