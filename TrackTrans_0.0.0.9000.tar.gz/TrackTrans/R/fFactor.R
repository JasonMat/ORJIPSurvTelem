#' Extraction of single factor level
#'
#' @param factV The factor (A spatial pixels data frame)
#' @param name The name of the factor variable in the spatial pixels data frame
#' @param level The name of the factor level to be extracted
#' @param bw The smoothing bandwidth to be applied (defaults to NA)
#'
#'
#' @return A raster stack with the original extracted factor level and smoothed gradients
#' @export


fFactor<-function(factV, name, level, bw=NA)
{

  # factV<-raster(habitats)
  # name<-"habitats"
  # level<-"Sand"
  # bw<-NA
  dat<-eval(parse(text=paste("factV@data$",name, sep="")))
  dat<-as.numeric(dat==level)
  eval(parse(text=paste("factV@data$",name,"<-dat", sep="")))
  names(factV@data)<-level
  cov<-fDrift(raster(factV),bw)
  return(cov)
}
