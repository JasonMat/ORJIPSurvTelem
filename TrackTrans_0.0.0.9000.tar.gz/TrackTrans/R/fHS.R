#' Step-selection function calculation
#'
#' @param x candidate x coordinates
#' @param y candidate y coordinates
#' @param covs A list of covariate rasters
#' @param di distance from central place - a raster
#' @param a vector of coefficient values for covariates in step selection function
#' @param ad vector of coefficients to be used in dealing with distance di
#' @param tp Proportion of trip completed
#' @param mode Whether homing ("Return") or constrained ("OU") behaviour should be assumed
#'
#' @return The new position selected
#' @export



fHS<-function(x,y,covs,di,a,ad,tp=0, mode="Return")
{

  tmid<- 1/2 # Half-saturation parameter for homing behaviour
  coords<-cbind(x,y)
  LL<-rep(0,length(a))
  for(i in 1:length(a))
  {
    r<-raster::rowFromY(covs[[i]],y)
    c<-raster::colFromX(covs[[i]],x)
    rc<-cbind(r,c)
    LL<-LL+a[i]*covs[[i]][rc]
  }
  LL<-LL+ad[1]*di[rc]+ad[2]*di[rc]*tp^10/(tp^10+tmid^10)
  hs<-exp(LL)
  pt<-sample(1:length(x),1,prob=hs)
  return(pt)
}
