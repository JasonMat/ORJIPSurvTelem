#' Individual Based Model for movement
#'
#' @param x0,y0 Starting position
#' @param T0 Starting time
#' @param tmax Duration of track
#' @param sigma Diffusivity
#' @param covs A list of covariate rasters
#' @param di distance from central place - a raster
#' @param a vector of coefficient values for covariates in step selection function
#' @param ad vector of coefficients to be used in dealing with distance di
#' @param bound Four-element vector defining study area boundary
#'
#' @return A pp-by-2 matrix of candidate positions
#' @export


fIBM<-function(x0,y0,T0,tmax,sigma, covs, di, a, ad, bound)
{

  #Data structures
  path<-matrix(c(x0,y0,T0+1), nrow=tmax, ncol=3, byrow=T)

  #Parameters
  pp<-10 # Number of candidate points for SSF

  #Simulation
  for(t in 2:tmax)
  {

    coords<-fSteps(pp, sigma, x=path[t-1,1], y=path[t-1,2], covs=append(covs,di), bound)
    pt<-fHS(coords[,1],coords[,2],covs,di,a,ad,tp=t/tmax, mode="Return")

    path[t,1]<-coords[pt,1]
    path[t,2]<-coords[pt,2]
    path[t,3]<-T0+t
  }


  return(path)
}
