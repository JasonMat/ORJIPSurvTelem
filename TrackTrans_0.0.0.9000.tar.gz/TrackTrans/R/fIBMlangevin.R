#' Individual Based Model for Langevin Diffusion
#'
#' @param x0,y0 Starting position
#' @param T0 Starting time
#' @param tmax Duration of track
#' @param covs A list of covariate raster stacks
#' @param di distance from central place - a raster stack
#' @param a vector of coefficient values for covariates in step selection function
#' @param ga Mobility sd (diffusivity)
#' @param bound Four-element vector defining study area boundary
#' @import MASS
#' @return A pp-by-2 matrix of candidate positions
#' @export


fIBMlangevin<-function(x0,y0,T0,tmax,covs, a, ga, bound)
{

  #Data structures
  path<-matrix(c(x0,y0,T0+1, NA,NA), nrow=tmax, ncol=5, byrow=T)
  Sigma<-matrix(c(ga^2,0,0,ga^2),2,2)
  btilde<-c(0,0)
  r<-raster::rowFromY(covs[[1]],y0)
  c<-raster::colFromX(covs[[1]],x0)
  #Simulation
  for(t in 2:tmax)
  {
    # Get raster positions

    x<-path[t-1,1]
    y<-path[t-1,2]

    btilde[1]<-0
    btilde[2]<-0

    for(i in 1:length(covs))
    {
      btilde[1]<-btilde[1]+a[i]*covs[[i]]$bx[r,c]
      btilde[2]<-btilde[2]+a[i]*covs[[i]]$by[r,c]
    }
    mu<-c(x,y)
    mu[1]<-x+ga^2/2*btilde[1]
    mu[2]<-y+ga^2/2*btilde[2]

    xy<-mvrnorm(1, mu,Sigma)
    xy[1]<-max(bound[1],min(bound[2],xy[1]))
    xy[2]<-max(bound[3],min(bound[4],xy[2]))
    r<-raster::rowFromY(covs[[1]],xy[2])
    c<-raster::colFromX(covs[[1]],xy[1])

    tst<-1
    for(i in 1:length(covs))
    {
      tst<-tst*(1-is.na(covs[[i]][[1]][r,c]))
      tst<-tst*(1-is.na(covs[[i]][[2]][r,c]))
      tst<-tst*(1-is.na(covs[[i]][[3]][r,c]))
    }

    if(tst==0)
    {
      path[t,1]<-path[t-1,1]
      path[t,2]<-path[t-1,2]
      path[t,3]<-T0+t
      path[t,5]<-path[t-1,5]
      path[t,4]<-path[t-1,4]
    } else {
      path[t,1]<-xy[1]
      path[t,2]<-xy[2]
      path[t,3]<-T0+t
      path[t,5]<-c
      path[t,4]<-r
    }


  }




  return(path)
}
