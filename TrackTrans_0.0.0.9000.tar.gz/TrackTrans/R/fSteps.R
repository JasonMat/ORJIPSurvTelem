#' Candidate points for step selection function
#'
#' @param pp number of points to be selected
#' @param sigma Diffusivity
#' @param x,y Current location
#' @param covs List of covariate rasters, used to avoid NA points
#' @param bound A vector of four map boundaries
#'
#' @return A pp-by-2 matrix of candidate positions
#' @export


fSteps<-function(pp, sigma, x, y, covs, bound)
{
  xx<-c()
  yy<-c()
  while(length(xx)<pp)
  {
    xys<-mvrnorm(1,mu=c(0,0),Sigma=diag(2)*sigma^2)
    x1<-max(bound[1],min(bound[2],x+xys[1]))
    y1<-max(bound[3],min(bound[4],y+xys[2]))
    r<-raster::rowFromY(covs[[1]],y1)
    c<-raster::colFromX(covs[[1]],x1)
    rc<-cbind(r,c)
    keep<-1

    for(i in 1:length(covs))
    {
      keep<-keep*(is.na(covs[[i]][[1]][rc])==0)
    }
    if(keep==1)
    {
      xx<-c(xx,x1)
      yy<-c(yy,y1)
    }
  }
  return(cbind(xx,yy))
}
