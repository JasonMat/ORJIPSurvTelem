#' Data containing sediment values for marine study area
#'
#' Contains six types of habitat
#'
#' @format A raster
#'
#' @source Aggregated in-house

#' data(habitats) # Lazy loading. Data becomes visible as soon as package is loaded
#' plot(habitats)
"habitats"
