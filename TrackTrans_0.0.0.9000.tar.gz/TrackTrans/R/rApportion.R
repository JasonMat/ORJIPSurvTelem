#' Generate bootstrap estimates of usage in bounded region
#'
#' @param dr number of draws from the posterior, for boostrapping
#' @param pars A data frame of parameter values, ordered.
#' @param covariates A list of covariate rasters
#' @param dis A list of distance rasters
#' @param pop Vector of population sizes
#' @param boundary A shape file for area boundary
#' @details
#' The order of the parameters must be the following:
#' 1) Intercept for adults
#' 2) Intercept for juveniles
#' 3) Alternating covariate coefficients for Adults and Juvs
#' 4) Distance-to-colony coefficients for Adults and Juvs
#' @return A list of matrices containing exposure estimates by colony (rows) and age stage (columns)
#' @details
#' The matrices contain the following information:
#' 1) Median exposure as a proportion of the colony's and age stage's usage
#' 2) Low 95% CI for (1)
#' 3) Upper 95% CI for (1)
#' 4) Median exposure as a proportion of the colony's and age stage's usage
#' 5) Low 95% CI for (4)
#' 6) Upper 95% CI for (4)
#' @export


rApportion<-function(dr, pars, covariates, dis, pop, boundary)
{
  nC<-length(pop)
  nCov<-length(covariates)
  ciP<-5 # Confidence interval percentile

  med<-lo<-hi<-medW<-loW<-hiW<-matrix(0,nC,2) # Summary results

  for(i in 1:nC) # Colonies
  {
    for(j in 1:2) # Juveniles/Adults
    {
      dat<-rep(0,dr)
      for(k in 1:dr) # MCMC draws
      {
        #Accessibility into the linear predictor first
        l<-pars[k,j] -pars[k,2*(1+nCov)+j]*dis[[i]]
        if(nCov>0)
        {
          for(c in 1:nCov)
          {
            l<-l+pars[k,2+2*(c-1)+j]*covariates[[c]]
          }
        }
        us<-exp(l)
        dat[k]<-terra::extract(us, boundary, fun = sum, na.rm = TRUE)[[2]]
        dat[k]<-dat[k]/sum(na.omit(as.matrix(us)))
      }

      datW<-dat*pop[i]/sum(2*pop)

      medW[i,j]<-mean(datW)
      loW[i,j]<-sort(datW)[ceiling(ciP/200*dr)]
      hiW[i,j]<-sort(datW)[floor((1-ciP/200)*dr)]

      med[i,j]<-mean(dat)
      lo[i,j]<-sort(dat)[ceiling(ciP/200*dr)]
      hi[i,j]<-sort(dat)[floor((1-ciP/200)*dr)]
    }


}

  return(list("Median Unweighted"=med,"Lower Unweighted"=lo,"Upper Unweighted"=hi,"Median Weighted"=medW,"Lower Weighted"=loW,"Upper Weighted"=hiW))
}
