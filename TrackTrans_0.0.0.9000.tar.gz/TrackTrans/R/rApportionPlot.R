#' Generate boostrap plot of all usage components (map form)
#'
#' @param dr number of draws from the posterior, for boostrapping
#' @param pars A data frame of parameter values, ordered.
#' @param covariates A list of covariate rasters
#' @param dis A list of distance rasters
#' @param pop Vector of population sizes
#' @param exCols Vector of the serial numbers of colonies to be used as plotting examples
#' @param colonyNames The names of the example colonies
#' @param dimPlot Arrangement of plots to be produced
#' @param mapTrue A map of true usage, if available
#' @details
#' The order of the parameters must be the following:
#' 1) Intercept for juveniles
#' 2) Intercept for adults
#' 3) Alternating covariate coefficients for Juvs and Adults
#' 4) Distance-to-colony coefficients for Juvs and Adults
#' @export


rApportionPlot<-function(dr, pars, covariates, dis, pop, exCols=c(1,2), colonyNames=c("Colony 1","Colony 2"), dimPlot=c(4,2), mapTrue=NULL)
{

  nC<-length(pop)
  nCov<-length(covariates)
  dum<-dis[[1]]*0
  names(dum)<-"Usage"
  us<-usJ<-usA<-dum
  usCJ<-usCA<-replicate(nC, dum,simplify = F)

  for(i in 1:nC) # Colonies
  {
    for(k in 1:dr) # MCMC trials
    {
      for(j in 1:2) #Juveniles/Adults
      {
        #Accessibility into the linear predictor first
        l<- pars[k,j]-pars[k,2*(1+nCov)+j]*dis[[i]]
        if(nCov>0)
        {
          for(c in 1:nCov)
          {
            l<-l+pars[k,2+2*(c-1)+j]*covariates[[c]]
          }
        }
        if(j==1)
        {
          usCJ[[i]]<-usCJ[[i]]+pop[i]*1/dr*exp(l)
        } else {
          usCA[[i]]<-usCA[[i]]+pop[i]*1/dr*exp(l)
        }
      }
    }
    usA<-usA+usCA[[i]]
    usJ<-usJ+usCJ[[i]]

  }
  pa<-sum(na.omit(as.matrix(usA)))/(sum(na.omit(as.matrix(usA)))+sum(na.omit(as.matrix(usJ))))
  us<-pa*usA+(1-pa)*usJ



  nlevs<-10
    par(mfrow=dimPlot)
    for(i in exCols)
    {

      map<-(1-pa)*pop[i]*usCJ[[i]]/sum(na.omit(as.matrix(usCJ[[i]])))
      map[is.na(map)]<--0.0000001
      image(log(map), main=paste("Juvs, ",colonyNames[i]))
      contour(map, add=TRUE, col="white",labels=NULL, nlevels=nlevs)
      contour(map, add=TRUE,col="black",levels=c(-0.000000009), labcex=0.1, lwd=2)
      map<-pa*pop[i]*usCA[[i]]/sum(na.omit(as.matrix(usCA[[i]])))
      map[is.na(map)]<--0.0000001
      image(log(map), main=paste("Adults,",colonyNames[i]))
      contour(map, add=TRUE, col="white",labels=NULL, nlevels=nlevs)
      contour(map, add=TRUE,col="black",levels=c(-0.000000009), labcex=0.1, lwd=2)
    }

    map<-pa*sum(pop)*usA/sum(na.omit(as.matrix(usA)))
    map[is.na(map)]<--0.0000001
    image(log(map), main="Adults")
    contour(map, add=TRUE, col="white",labels=NULL, nlevels=nlevs)
    contour(map, add=TRUE,col="black",levels=c(-0.000000009), labcex=0.1, lwd=2)
    map<-(1-pa)*sum(pop)*usJ/sum(na.omit(as.matrix(usJ)))
    map[is.na(map)]<--0.0000001
    image(log(map), main="Juveniles")
    contour(map, add=TRUE, col="white",labels=NULL, nlevels=nlevs)
    contour(map, add=TRUE,col="black",levels=c(-0.000000009), labcex=0.1, lwd=2)
    map<-sum(pop)*us/sum(na.omit(as.matrix(us)))
    map[is.na(map)]<--0.0000001
    image(log(map), main="Aggregate")
    contour(map, add=TRUE, col="white",labels=NULL, nlevels=nlevs)
    contour(map, add=TRUE,col="black",levels=c(-0.000000009), labcex=0.1, lwd=2)
    if(is.null(mapTrue)==0)
    {
      map<-map1<-mapTrue
      map[is.na(map)]<--0.0000001
      image(log(map), main="True Aggregate")
      contour(map, add=TRUE, col="white",labels=NULL, nlevels=nlevs)
      contour(map, add=TRUE,col="black",levels=c(-0.000000009), labcex=0.1, lwd=2)
    }
    par(mfrow=c(1,1))
}
