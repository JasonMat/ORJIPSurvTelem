#' Sampling survey transect detections
#'
#' @param tags A vector of the number of tags deployed at each colony.
#' @param thinTg Thinning parameter. Regulates time interval between fixes.
#' @param allCols Vector of the colony IDs from which each simulated animal came.
#' @param allData List of all usage data produced by IBM (by individual path).
#' @param adult Vector of age stage for each individual in simulated population.
#' @param minAgeTagged The age class limit . Value 1 if all ages, 2 (default) if only adults.
#'
#' @return A list containing full tag data and tag line frame for visualisation. Also, vector of animal IDs, colonies of origin and age stages for each tagged individual.
#' @export



sampleTrack<-function(tags,thinTg, allCols, allData, adult, minAgeTagged=2)
{

  noTg<-sum(tags)
  nC<-length(tags)

  # Telemetry data
  n<-length(allData)
  tagData<-vector("list",1) # Main data structure
  tagLines<-vector("list",1) # Data structure for plotting
  currentTag<-1
  allIDs<-c()
  for(i in 1:nC) # Loops over number of colonies
  {
    maxIndisCol<-sum(as.logical((allCols==i) * (adult>=minAgeTagged)))
     # Individuals in population from this colony
    if(maxIndisCol>0)
    {
      # Choose ids of tagged individuals
      if(maxIndisCol<tags[i])
        {
        print(paste("Warning: The number of tags requested for colony ",i," exceed the number of simulated individuals. Tags will be adjusted accordingly."))
        tags[i]<-maxIndisCol
      }
      ids<-sample(seq(1:n)[as.logical((allCols==i) * (adult>=minAgeTagged))], size=tags[i],replace=FALSE)
      allIDs<-c(allIDs,ids)
      if(tags[i]>0)
      {
        for(j in 1:tags[i]) # collects data from each tag
        {
          locs<-nrow(allData[[ids[j]]])
          pts<-seq(1, locs ,thinTg)
          if(currentTag==1)
          {
            tagData[[1]]<-allData[[ids[j]]][pts,]
            tagLines[[1]]<-Lines(list(Line(tagData[[currentTag]][,1:2])), ID=as.character(ids[j]))

          } else {
            tagData<-append(tagData, list(allData[[ids[j]]][pts,]))
            tagLines<-append(tagLines, list(Lines(list(Line(tagData[[currentTag]][,1:2])), ID=as.character(ids[j]))))

          }
         currentTag<-currentTag+1
        }
      }
    }
  }
  return(list(tagData, tagLines, allIDs, allCols[allIDs], adult[allIDs]))
}
