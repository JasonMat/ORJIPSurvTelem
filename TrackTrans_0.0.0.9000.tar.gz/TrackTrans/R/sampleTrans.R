#' Sampling survey transect detections
#'
#' @param allData Complete dataset of animal usage, as produced by IBM
#' @param transects Transect spatial point data frame
#' @param stepTr Spacing of transect points
#' @param p Probability of detecting a proximate point
#' @param detDist Effective transect strip width
#'
#' @return An data frame of transect positions with detection counts and covariate values
#' @export



sampleTrans<-function(allData,transects, stepTr=1, p=1, detDist)
{

  # Data frame with all animal ids, locations and times
  useTru<-data.frame("id"=rep(1,nrow(allData[[1]])),
                     "Row"=allData[[1]][,4],
                     "Col"=allData[[1]][,5],
                     "lon"=allData[[1]][,1],
                     "lat"=allData[[1]][,2],
                     "time"=allData[[1]][,3])
  for(i in 1:n)
  {
    useTru<-rbind(useTru, data.frame("id"=rep(1,nrow(allData[[i]])),
                                     "Row"=allData[[i]][,4],
                                     "Col"=allData[[i]][,5],
                                     "lon"=allData[[i]][,1],
                                     "lat"=allData[[i]][,2],
                                     "time"=allData[[i]][,3]))
  }

  # Extraction of animal detections
  samplePoints<-seq(1,nrow(transects),stepTr)
  surveyDat<-cbind(transects[samplePoints,], "Count"=rep(0,length(samplePoints)))

  cnt<-1
  for(i in samplePoints)
  {
    # Distances of animal locations from survey point
    dist<-sqrt((transects[i,]$lat-useTru$lat)^2+(transects[i,]$lon-useTru$lon)^2)
    chunk<-useTru[dist<detDist,]
    surveyDat$Count[cnt]<-rbinom(1, nrow(chunk), p)
    cnt<-cnt+1
  }
  return(surveyDat)
}
