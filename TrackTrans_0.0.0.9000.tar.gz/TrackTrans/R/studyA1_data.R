#' Data containing boundary of offshore area of interest
#'
#' Contains shape of marine area of interest.
#'
#' @format A shapefile
#'
#' @source Created in-house as an example

#' data(studyA1) # Lazy loading. Data becomes visible as soon as package is loaded
#' plot(studyA1)
"studyA1"
