#' Data containing boundary of study area
#'
#' Contains shape of study area. Marine area only, excluding land and coastal areas.
#'
#' @format A shapefile
#'
#' @source Aggregated in-house

#' data(studyA) # Lazy loading. Data becomes visible as soon as package is loaded
#' plot(studyA)
"studyA"
