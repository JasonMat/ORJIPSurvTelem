#' Data containing example transect lines
#'
#' Transect location points
#'
#' @format spatial points data frame for transect lines
#'
#' @source Aggregated in-house

#' data(transects) # Lazy loading. Data becomes visible as soon as package is loaded
#' plot(transects)
"transects"
